import React from 'react'
import Home from './home/page'

 const page = () => {
   return (
     <div>
      <Home/>
     </div>
   )
 }
 
 export default page
 